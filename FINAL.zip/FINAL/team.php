<?php
    define("TITLE","Team | Fine Dining");
    include('assets/includes/header.php');
?>
<div id="team-members" class="cf">
    <h1>Our team at Franklin's</h1>
    <p>We're small but mighty. Franklin's Fine Dining has been a family-owned and run business since a long time, and we're proud of it! When you get these three together, you never know what can happen. But you can count on one thing: <strong>The best food you've ever had. Ever.</strong></p>
    <hr>
    <?php 
        foreach($teamMembers as $members)
        {
        ?>
    <div class="member">
        <img src="assets/img/<?php echo $members["img"]; ?>.png" alt="<?php echo $members["name"]; ?>">
        <h2><?php echo $members["name"]; ?></h2>
        <p><?php echo $members["bio"]; ?></p>
    </div><!-- member -->
    <?php
        }
    ?>
</div><!-- team-members -->
<?php
        include('assets/includes/footer.php');
?>
