<?php
$navItems = array(
                    array(
                    "slug" => "index.php",
                    "title"=> "Home"
                    ),
                    array(
                    "slug" => "team.php",
                    "title"=> "Team"
                    ),
                    array(
                    "slug" => "menu.php",
                    "title"=> "Menu"
                    ),
                    array(
                    "slug" => "contact.php",
                    "title"=> "Contact"
                    ),
);

//Team Members
$teamMembers = array(
                    array(
                        "name" => "HK_07",
                        "position" => "Owner",
                        "bio" => "HK(Frankie III) is the grandson of the original Franklin, He is the owner of Franklin's Fine Dining.",
                        "img" => "frankie"
                    ),
                    array(
                        "name" => "Francis",
                        "position" => "General Manager",
                        "bio" => "Francis knows her stuff. She is the elder sister of HK, she runs the show. Don't miss her Margherita's.",
                        "img" => "francis"
                    ),
                    array(
                        "name" => "Carlos",
                        "position" => "Head Chef",
                        "bio" => "Carlos is the epitome of the phrase &ldquo;Don't judge a book by it's cover&rdquo; &mdash; You simply cannot find a better chef.",
                        "img" => "carlos"
                    ),
);

//Menu Items
$menuItems = array(
                "club-sandwich" => array(
                    "title" => "Club Sandwich ",
                    "price" => 11,
                    "blurb" => "A club sandwich, also called a clubhouse sandwich, is a sandwich of bread (occasionally toasted), sliced cooked poultry, fried bacon, lettuce, tomato, and mayonnaise. It is often cut into quarters or halves and held together by cocktail sticks. ... The club sandwich may have originated at the Union Club of New York City.",
                    "drink" => "Club Soda"
                ),
                "dill-salmon" => array(
                    "title" => "Lemon &amp; Dill Salmon ",
                    "price" => 18,
                    "blurb" => "Mix the butter and lemon juice in a small bowl, and drizzle over the salmon. Season with dill, garlic powder, sea salt, and pepper. Bake 25 minutes in the preheated oven, or until salmon is easily flaked with a fork.",
                    "drink" => "Fancy Wine"
                ),
                "super-salad" => array(
                    "title" => "The Super Salad<sup>&reg;</sup> ",
                    "price" => 34,
                    "blurb" => "The best food out here for the fitness freaks. The people who have become obese and want to lose weight and burn their fat should definitely try this. It includes all vegetables.",
                    "drink" => "Jug o' water"
                ),
                "margherita-pizza" => array(
                    "title" => "Margherita ",
                    "price" => 23,
                    "blurb" => "2 cloves roasted garlic, finely chopped. 1/4 cup your favorite pizza or tomato sauce. 8 ounces mozzarella cheese, sliced into 1/2 inch thick pieces. 2 plum tomatoes, sliced (or any tomato you like)",
                    "drink" => "Beer with a lime"
                ),
);

?>