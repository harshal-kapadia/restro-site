<?php
    $companyName = "Fine Dining";
    include('assets/includes/arrays.php');
?>
<!doctype HTML>
<html>
<head>
<title><?php echo TITLE; ?></title>
<link href="assets/styles.css" rel="stylesheet">
</head>
<body id="final-example">
<div class="wrapper">
<div id="banner">
    <a href="/" title="Return to Home">
        <img src="assets/img/banner.png" alt="Fine Dine">
    </a>
    </div><!-- banner -->
    <div id="nav">
        <?php include('assets/includes/nav.php'); ?>
    </div><!-- nav -->
    <div class="'content">
