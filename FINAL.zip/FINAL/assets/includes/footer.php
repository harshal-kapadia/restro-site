 <div id="footer" class="cf">
            <div class="column three">
            <strong>Phone</strong>
            9920345678
            </div>
            <div class="column three">
            <strong>Location</strong>
            123, Malabar Hills<br>
            Mumbai.
            </div>
            <div class="column three last">
            <strong>Hours</strong>
            <em>Tuesday - Thursday</em><br>
            1:00pm - 9:00pm<br><br>
            <em>Friday - Saturday</em><br>
            3:00pm -11:00pm<br><br>
            <em>Sunday - Monday</em><br>
            Closed<br><br>
            <?php include('assets/includes/store-hours.php'); ?>
            </div>
        </div><!-- footer -->
        <small>&copy;<?php echo date('Y'); ?> <?php echo $companyName; ?></small>
    </div><!-- content -->
</div><!-- wrapper -->
<div class="copyright-info">
    <?php include('copyright.php'); ?>
    </div><!-- copyright-info -->
</body>
</html>