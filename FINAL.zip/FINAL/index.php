<?php
    define("TITLE","Home | Fine Dining");
    include('assets/includes/header.php');
?>
<div id="philosophy">
    <hr>
    <h1>Franklin's philosophy of fine dining</h1>
    <p>Here at Franklin's, we know that good food isn't just about how expensive the dish is. We're not pompous, we're proud of. We're proud of our work, our quality, our environment, and our love for food and family.</p>
    <hr>
</div><!-- philosophy -->
<?php
    include('assets/includes/footer.php');
?>