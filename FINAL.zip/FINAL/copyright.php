<h4>Code Dynamic Websites with PHP</h4>
<h5>Copyright &copy;<?php echo date('Y');?> <a href="/" target="_blank">HK</a> <a href="/" target="_blank"></a></h5>